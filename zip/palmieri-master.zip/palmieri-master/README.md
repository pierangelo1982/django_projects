palmieri - install requirements
========

django

easy-thumbnails

django-image-cropping

django-filer

django-contact-form

